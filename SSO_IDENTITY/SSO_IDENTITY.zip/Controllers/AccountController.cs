﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.UI.V4.Pages.Account.Internal;
using Microsoft.AspNetCore.Mvc;

namespace SSO_IDENTITY.Controllers
{
    //public class AccountController : Controller
    //{
    //    private readonly SignInManager<IdentityUser> _signInManager;
    //    private readonly ILogger<LogoutModel> _logger;
  
    //    public AccountController(SignInManager<IdentityUser> signInManager, ILogger<LogoutModel> logger)
    //    {
    //        _signInManager = signInManager;
    //        _logger = logger;
    //    }

    //    public IActionResult Index()
    //    {
    //        return View();
    //    }

    //    public async Task<IActionResult>Signout()
    //    {
    //        await _signInManager.SignOutAsync();
    //        return Redirect("https://localhost:44339/");
    //    }


        
    //}
}
